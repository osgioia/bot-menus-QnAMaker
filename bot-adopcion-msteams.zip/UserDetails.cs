﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
//
// Generated with Bot Builder V4 SDK Template for Visual Studio CoreBot v4.6.2

namespace Microsoft.BotBuilderSamples
{
    public class UserDetails
    {
        public string Id { get; set; }
        public string UserEmail { get; set; }
        public string UserName { get; set; }
    }
}