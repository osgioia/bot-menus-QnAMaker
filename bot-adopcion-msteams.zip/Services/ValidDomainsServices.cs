﻿namespace QnABot.Services
{
    public interface ValidDomainsServices
    {
        bool isValidDomain(string domain);
    }
}