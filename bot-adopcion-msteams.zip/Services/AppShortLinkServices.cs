﻿namespace QnABot.Services
{
    public interface AppShortLinkServices
    {
        public string getAppUrlMsTeams(string AppId);
    }
}