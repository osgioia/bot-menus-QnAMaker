﻿namespace QnABot.Models
{
    public class ValidDomains
    {
        public long ID { get; set; }
        public string Domain { get; set; }
    }
}
