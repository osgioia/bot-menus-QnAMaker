﻿using QnABot.Models;

namespace QnABot.Repository.Implementations
{
    public interface IQnAReceivedRepository : IGenericRepository<UserQnAReceived>
    {

    }
}
