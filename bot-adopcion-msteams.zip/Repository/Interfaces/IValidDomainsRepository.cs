﻿using QnABot.Models;

namespace QnABot.Repository.Implementations
{
    public interface IValidDomainsRepository : IGenericRepository<ValidDomains>
    {

    }
}
