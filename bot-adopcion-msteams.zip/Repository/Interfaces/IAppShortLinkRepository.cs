﻿using QnABot.Models;

namespace QnABot.Repository.Implementations
{
    public interface IAppShortLinkRepository : IGenericRepository<AppShortLink>
    {

    }
}
